﻿interface Date {
    YearsFromToday(): number;
}

Date.prototype.YearsFromToday = function (): number {
    // implement logic
    return 1;
}