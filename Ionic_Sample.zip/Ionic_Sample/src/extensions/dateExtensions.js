Date.prototype.YearsFromToday = function () {
    // implement logic
    return 1;
};
//# sourceMappingURL=dateExtensions.js.map