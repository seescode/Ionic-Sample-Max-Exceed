﻿export const environment = {
    origin: 'https://api.github.com'
}