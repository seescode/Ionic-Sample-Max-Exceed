export var environment = {
    origin: 'http://localhost:50936/api'
};
//# sourceMappingURL=environment.js.map