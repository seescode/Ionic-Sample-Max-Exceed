﻿export interface IHasId {
   id: number;
}