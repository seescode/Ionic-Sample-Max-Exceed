﻿export class PageListConfiguration {
    canDelete: boolean;
    canCreate: boolean;
}