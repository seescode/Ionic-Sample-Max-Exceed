﻿export interface EditOptions {
    isEditing: boolean;
}